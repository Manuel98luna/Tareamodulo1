namespace FastDeliveryAPI.Exceptions;

public class ValidarNumeroTelefono : ApplicationException
{
    public ValidarNumeroTelefono(string numero) : base ($"{numero} no se permiten numeros decimales para numero de telefono")
    {

    }
}